package com.example.keyapp;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class OverlayService extends Service {

    private WindowManager mWindowManager;
    private View mOverlayView;
    private long lastClickTime = 0;
    private int clickCount = 0;

    public OverlayService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        mOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;

        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mWindowManager.addView(mOverlayView, params);

        // Make the overlay view draggable
        mOverlayView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        // Triple tap detection
                        long currentTime = System.currentTimeMillis();
                        if (currentTime - lastClickTime < 500) { // 500ms window for triple tap
                            clickCount++;
                        } else {
                            clickCount = 1;
                        }
                        lastClickTime = currentTime;

                        if (clickCount == 3) {
                            Toast.makeText(OverlayService.this, "Triple tap detected!", Toast.LENGTH_SHORT).show();
                            // Toggle visibility of the panel content
                            LinearLayout panelContent = mOverlayView.findViewById(R.id.panel_content);
                            if (panelContent.getVisibility() == View.VISIBLE) {
                                panelContent.setVisibility(View.GONE);
                            } else {
                                panelContent.setVisibility(View.VISIBLE);
                            }
                            clickCount = 0; // Reset count after action
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        mWindowManager.updateViewLayout(mOverlayView, params);
                        return true;
                }
                return false;
            }
        });

        // Example buttons in the overlay
        Button closeButton = mOverlayView.findViewById(R.id.close_button);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf(); // Stop the service and remove the overlay
            }
        });

        Button feature1Button = mOverlayView.findViewById(R.id.feature1_button);
        feature1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(OverlayService.this, "Funcionalidade 1 ativada!", Toast.LENGTH_SHORT).show();
            }
        });

        Button feature2Button = mOverlayView.findViewById(R.id.feature2_button);
        feature2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(OverlayService.this, "Funcionalidade 2 ativada!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mOverlayView != null) {
            mWindowManager.removeView(mOverlayView);
        }
    }
}
