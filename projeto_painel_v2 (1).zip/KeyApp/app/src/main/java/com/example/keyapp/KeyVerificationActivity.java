package com.example.keyapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class KeyVerificationActivity extends AppCompatActivity {

    private static final int REQUEST_OVERLAY_PERMISSION = 100;
    private EditText keyInput;
    private Button verifyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_key_verification);

        keyInput = findViewById(R.id.key_input);
        verifyButton = findViewById(R.id.verify_button);

        verifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String key = keyInput.getText().toString().trim();
                if (key.isEmpty()) {
                    Toast.makeText(KeyVerificationActivity.this, "Por favor, insira uma chave.", Toast.LENGTH_SHORT).show();
                } else {
                    checkOverlayPermission();
                }
            }
        });
    }

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
        } else {
            verifyKeyAndStartOverlay();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                verifyKeyAndStartOverlay();
            } else {
                Toast.makeText(this, "Permissão de sobreposição de tela negada. O painel não poderá ser exibido.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void verifyKeyAndStartOverlay() {
        String key = keyInput.getText().toString().trim();
        // TODO: Implementar a lógica real de verificação da chave com um backend.
        // Por enquanto, vamos simular uma verificação simples.
        boolean isValidKey = simulateKeyVerification(key);

        if (isValidKey) {
            Toast.makeText(this, "Chave verificada com sucesso!", Toast.LENGTH_SHORT).show();
            Intent serviceIntent = new Intent(this, OverlayService.class);
            startService(serviceIntent);
            finish(); // Fecha a atividade de verificação após iniciar o serviço
        } else {
            Toast.makeText(this, "Chave inválida ou expirada.", Toast.LENGTH_SHORT).show();
        }
    }

    private void verifyKeyAndStartOverlay() {
        final String key = keyInput.getText().toString().trim();
        
        // Usando Firebase Realtime Database para verificar a chave
        // Nota: Você precisará adicionar o arquivo google-services.json no seu projeto Android Studio/AIDE
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("keys").child(key);
        
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    long expirationDate = dataSnapshot.child("expiration").getValue(Long.class);
                    if (System.currentTimeMillis() < expirationDate) {
                        Toast.makeText(KeyVerificationActivity.this, "Chave válida!", Toast.LENGTH_SHORT).show();
                        startService(new Intent(KeyVerificationActivity.this, OverlayService.class));
                        finish();
                    } else {
                        Toast.makeText(KeyVerificationActivity.this, "Chave expirada!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(KeyVerificationActivity.this, "Chave não encontrada!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(KeyVerificationActivity.this, "Erro na verificação: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
